from transformers import pipeline

translator = pipeline("translation_en_to_es", model="Helsinki-NLP/opus-mt-en-es")
print(translator("Hi, How are you? I'am from India. Where are you from?"))  
