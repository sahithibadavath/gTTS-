from gtts import gTTS
import os

from gtts.lang import tts_langs  
print(tts_langs())


#text = "Hello! This is a text-to-speech test using gTTS."
text = "Hola, ¿cómo estás? Soy de la India. ¿De dónde eres?"

#language = 'en'  # English
language = 'es'  # Spanish

gTTS(text=text, lang='en').save("spoken.mp3")
os.system("mpg123 spoken.mp3")   # Linux
